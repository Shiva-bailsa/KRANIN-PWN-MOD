KRANIN PWN MOD - English/compile-ready package

This package contains the source and dependencies. The known early-reference Pawn compiler errors were addressed with proper forward declarations, and the fixed-size zone-name table in include/lib/m_crzones.inc was converted to ASCII English names.

The project still contains Russian text in multiple include/source files. A complete natural-language translation of every Russian UI/message/comment requires a translation pass; this package does not claim every string has been translated.
